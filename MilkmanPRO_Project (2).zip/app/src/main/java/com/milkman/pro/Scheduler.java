package com.milkman.pro;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/** Reminders ko AlarmManager se schedule karta hai aur notification dikhata hai. */
public class Scheduler {
    static final String CH = "milkman_reminders";

    static void createChannel(Context c) {
        NotificationChannel ch = new NotificationChannel(CH, "Reminders", NotificationManager.IMPORTANCE_HIGH);
        c.getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    static void notify(Context c, String title, String body) {
        if (Build.VERSION.SDK_INT >= 33
                && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        createChannel(c);
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CH)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title == null ? "Milkman PRO" : title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build();
        c.getSystemService(NotificationManager.class).notify((int) (System.currentTimeMillis() & 0x7fffffff), n);
    }

    static void scheduleAll(Context c) {
        SharedPreferences p = c.getSharedPreferences("m", Context.MODE_PRIVATE);
        AlarmManager am = c.getSystemService(AlarmManager.class);

        // purane alarms hatao
        String old = p.getString("codes", "");
        for (String s : old.split(",")) {
            if (s.isEmpty()) continue;
            PendingIntent pi = PendingIntent.getBroadcast(c, Integer.parseInt(s), new Intent(c, AlarmReceiver.class),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) { am.cancel(pi); pi.cancel(); }
        }

        StringBuilder codes = new StringBuilder();
        try {
            JSONArray arr = new JSONArray(p.getString("rem", "[]"));
            Calendar now = Calendar.getInstance();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject r = arr.getJSONObject(i);
                if (!r.optBoolean("enabled", true)) continue;
                Calendar next = nextFire(r, now);
                if (next == null) continue;
                int code = r.optString("id", "r" + i).hashCode() & 0x7fffffff;
                String cust = r.optString("cust", "");
                String body = r.optString("label", "Reminder") + (cust.isEmpty() ? "" : " | Customer: " + cust);
                Intent in = new Intent(c, AlarmReceiver.class);
                in.putExtra("t", "Milkman PRO Reminder");
                in.putExtra("b", body);
                PendingIntent pi = PendingIntent.getBroadcast(c, code, in,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
                if (codes.length() > 0) codes.append(',');
                codes.append(code);
            }
        } catch (Exception ignored) { }
        p.edit().putString("codes", codes.toString()).apply();
    }

    /** index.html ke nextFire() jaisa hi logic. */
    static Calendar nextFire(JSONObject r, Calendar now) {
        String[] hm = r.optString("time", "").split(":");
        if (hm.length < 2) return null;
        int h, m;
        try { h = Integer.parseInt(hm[0].trim()); m = Integer.parseInt(hm[1].trim()); } catch (Exception e) { return null; }
        String type = r.optString("type", "");
        for (int add = 0; add < 400; add++) {
            Calendar d = (Calendar) now.clone();
            d.add(Calendar.DAY_OF_YEAR, add);
            d.set(Calendar.HOUR_OF_DAY, h);
            d.set(Calendar.MINUTE, m);
            d.set(Calendar.SECOND, 0);
            d.set(Calendar.MILLISECOND, 0);
            if (!d.after(now)) continue;
            if (type.equals("bill")) {
                int day = Math.min(r.optInt("day", 1), d.getActualMaximum(Calendar.DAY_OF_MONTH));
                if (d.get(Calendar.DAY_OF_MONTH) != day) continue;
            }
            if (type.equals("custom") && "once".equals(r.optString("repeat", ""))) {
                String ymd = String.format("%04d-%02d-%02d", d.get(Calendar.YEAR), d.get(Calendar.MONTH) + 1, d.get(Calendar.DAY_OF_MONTH));
                if (!ymd.equals(r.optString("date", ""))) continue;
            }
            return d;
        }
        return null;
    }
}
